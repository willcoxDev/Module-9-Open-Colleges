I only used the Acme Database creation script and did not edit it. 

Therefore the Acme Database script that was provided can we used.